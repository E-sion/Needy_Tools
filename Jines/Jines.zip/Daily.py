import pandas as pd

Jines_file = r"Jine.xlsx"

# # 读取与查询
Jines = pd.read_excel(Jines_file)

daily = Jines.loc[(Jines['Category'] == 'Random Noon Event: Daily') & (
    Jines['Speaker/Action (in blue)'].str.contains('ame', regex=True, na=False))]['BodyCn']
# 输出全部的数值，并且保存到一个txt里面，名称为daily.txt
daily.to_csv('daily.txt', index=False, header=False)

print(daily)
