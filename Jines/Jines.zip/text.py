# 读取原始的txt文件
import os
import shutil
import re
from collections import defaultdict

from langchain.chat_models import ChatOpenAI
from langchain.schema import (
    AIMessage,
    HumanMessage,
    SystemMessage
)
import openai


def process_text(text):
    # 使用正则表达式匹配所有的Attribute Change
    matches = re.findall(r'(### Option-\d+.*?)(Attribute Change:.*?)(### Option-\d+|$)', text, re.DOTALL)

    new_text = ''
    for match in matches:
        option_text = match[0]
        attribute_changes = match[1].split('\n')
        attribute_changes = [change for change in attribute_changes if change.strip()]

        # 计算所有Attribute Change的总和
        total_changes = defaultdict(float)
        for change in attribute_changes:
            for attr in ['Affection', 'Stress', 'Darkness']:
                if attr in change:
                    total_changes[attr] += float(re.search(f'{attr}: (-?\d+\.?\d*)', change).group(1))

        # 移除原有的Attribute Change，并添加新的Attribute Change
        option_text = re.sub(r'Attribute Change:.*', '', option_text, flags=re.DOTALL)
        if total_changes:
            option_text += 'Attribute Change: ' + ' '.join(
                f'{attr}: {value}' for attr, value in total_changes.items()) + '\n'
        else:
            option_text += 'Attribute Change: None\n'

        new_text += option_text

    return new_text


def copy_files_with_content(source_directory, target_directory):
    for filename in os.listdir(source_directory):
        if filename.endswith(".txt"):
            with open(os.path.join(source_directory, filename), 'r', encoding="utf-8") as file:
                lines = file.readlines()
            if any("### Option-2" in line for line in lines) and any("Reply：" in line for line in lines):
                shutil.copy(os.path.join(source_directory, filename), target_directory)


def process_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    new_lines = []
    skip = False
    for line in lines:
        if 'Attribute Change: None' in line:
            skip = True
        elif 'Option-' in line and skip:
            skip = False
        if not skip:
            new_lines.append(line)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)


def process_directory(dir_path):
    for root, dirs, files in os.walk(dir_path):
        for file in files:
            if file.endswith('.txt'):  # or whatever file type you're processing
                process_file(os.path.join(root, file))


# 小数转整数
def process_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    content = re.sub(r'(\d+)\.0\b', r'\1', content)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)


def process_directory(dir_path):
    for root, dirs, files in os.walk(dir_path):
        for file in files:
            if file.endswith('.txt'):  # or whatever file type you're processing
                process_file(os.path.join(root, file))


import json


def process_jsonl(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    openai.api_key = 'sk-KRQTbLLQvizMRHBnT5FJ9UPZNyMD8J4I6HxudguLcJGX8qgS'
    openai.api_base = 'https://openkey.cloud/v1'

    decoder = json.JSONDecoder()
    chat = ChatOpenAI(temperature=0, openai_api_key=openai.api_key, openai_api_base=openai.api_base)

    for i in range(len(lines)):
        objs = []
        s = lines[i]
        while s:
            obj, pos = decoder.raw_decode(s)
            objs.append(obj)
            s = s[pos:].lstrip()

        for obj in objs:
            prefix = obj['prefix']

            messages2 = [
                # 相当于我们提问前让chatgpt进行角色扮演
                SystemMessage(
                    content="从现在开始，你是一个情感分析bot，我会给你一段角色A的对话，你需要将该段对话转换为单个emoji,"
                            "注意：emoji的范围包括情感和代表事物的emoji。"
                            "你只可以使用一个emoji来表示该段对话。"),
                AIMessage(content="好的，我会严格遵守你的要求,把用户的对话转换为单个emoji。"),
                SystemMessage(content='''
                A:阿P，看！我买了小发发'
                '''),
                AIMessage(content="☺"),
                SystemMessage(content=f'''
                A:{prefix}'
                ''')
            ]

            obj['prefix_emoji'] = chat(messages2).content
            print('prefix_emoji: ', obj['prefix_emoji'])

            # for option in obj['options']:
            #     # 这里是生成emoji的部分，你可能需要根据你自己的需求来修改这部分的代码
            #     user = option['user']
            #     reply = option['reply']
            #     attribute_change = option['attribute_change']
            #
            #     messages = [
            #         # 相当于我们提问前让chatgpt进行角色扮演
            #         SystemMessage(
            #             content="从现在开始，你是一个情感分析bot，我会给你一段糖糖和B的对话记录和A的情感变化数值，你需要仔细分析对话记录和情感变化数值,"
            #                     "然后输出一个emoji来表示糖糖当前的情感状态。"
            #                     "注意：你需要尽可能的扩大emoji的范围，既包括情感emoji，也包括代表事物的emoji"),
            #         AIMessage(content="好的，我会严格遵守你的要求。"),
            #         SystemMessage(content='''
            #         A:阿P，看！我买了小发发'
            #         "B:真好看，跟糖糖好像"
            #         "A:对吧！我不在的时候，你就把小花花当成糖糖，好好疼爱它吧！"
            #         "A的感情数值变化：Stress: -1
            #         '''),
            #         AIMessage(content="❤"),
            #         SystemMessage(content=f'''
            #         A:{prefix}'
            #         "B:{user}"
            #         "A:{reply}"
            #         "A的感情数值变化：{attribute_change}
            #         '''
            #                       )
            #     ]
            #
            #     option['option_emoji'] = chat(messages).content
            #     print('option_emoji: ', option['option_emoji'], '\n')

        lines[i] = '\n'.join(json.dumps(obj, ensure_ascii=False) for obj in objs)

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


# 使用这个函数来处理你的JSONL文件
process_jsonl('emoji_story_23.jsonl')

# process_directory('move')
# copy_files_with_content('events', 'move')
